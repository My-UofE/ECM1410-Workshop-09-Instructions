import java.util.*;
import java.time.LocalDate;
import java.io.*;
import java.util.logging.*;

public class MessageBoard implements MessageBoardInterface {
    private static Logger logger = Logger.getLogger(MessageBoard.class.getName());

    private List<Post> posts;
    private String boardName;

    public MessageBoard(String boardName) {
        this.boardName = boardName;
        this.posts = new ArrayList<>();
    }

    public String getBoardName() {
        return boardName;
    }

    public int[] getPostIDs() {
        int[] postIDs = new int[posts.size()];
        int i = 0;
        for (Post post : posts) {
            postIDs[i++] = post.getPostID();
        }
        return postIDs;
    }

    public int getPostIndex(int postID) throws IDInvalidException {
        for (int i = 0; i < posts.size(); i++) {
            if (posts.get(i).getPostID() == postID) {
                return i;
            }
        }
        throw new IDInvalidException("Invalid post ID.");
    }

    public int addPost(String author, String subject, String message){
        // this should create a new post and add it to the posts ArrayList
        // and return the postID of the newly added post
        Post post = new Post(author, subject, message);
        posts.add(post);
        return post.getPostID();

    }

    public int addPost(String author, String subject, String message, int epochDate){
        // this should create a new post with the specified date and add it to the posts ArrayList
        // and return the postID of the newly added post
        Post post = new Post(author, subject, message, LocalDate.ofEpochDay(epochDate));
        posts.add(post);
        return post.getPostID();
    }


    public String getFormattedPost(int postID) throws IDInvalidException{
        // this should make use of getPostIndex to access the post
        // and print it using the .toFormattedString() method
        int index = getPostIndex(postID);
        return posts.get(index).toFormattedString();
    }

    public int[] postListToArray(List<Integer> postIDs) {
        int[] postIDArray = new int[postIDs.size()];
        for (int i = 0; i < postIDs.size(); i++) {
            postIDArray[i] = postIDs.get(i);
        }
        return postIDArray;
    }

    public void deletePost(int postID) throws IDInvalidException{
        // this should make use of getPostIndex to access the post
        // and remove it from the posts ArrayList

        int index = getPostIndex(postID);
        //logger.info("MessageBoard deletePost:" + posts.get(index).toString());

        posts.remove(index);
    }

    public int[] searchPostsBySubject(String keyword){
        logger.info("MessageBoard searchPostsBySubject: " + keyword);

        List<Integer> matchingPostIDs = new ArrayList<>();
        for (Post post : posts) {
            if (post.getSubject().toLowerCase().contains(keyword.toLowerCase())) {
                matchingPostIDs.add(post.getPostID());
            }
        }
        return postListToArray(matchingPostIDs);
    }

    public int[] searchPostsByDate(int startDate, int endDate){
        logger.info("MessageBoard searchPostsByDate: " + startDate + " " + endDate);

        List<Integer> matchingPostIDs = new ArrayList<>();
        for (Post post : posts) {
            if (post.getDate() >= startDate && post.getDate() <= endDate) {
                matchingPostIDs.add(post.getPostID());
            }
        }
        return postListToArray(matchingPostIDs);
    }

    public void saveMessageBoard(String filename) throws IOException{
        logger.info("MessageBoard saveMessageBoard: " + filename);
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename));
        // store boardName attribute
        out.writeObject(boardName);
        // convert posts to array Post[] to simplifies the deserialisation
        Post[] postArray = posts.toArray(new Post[posts.size()]);
        //  store Post array
        out.writeObject(postArray);
        out.close();
    } 

    public void loadMessageBoard(String filename) throws IOException, ClassNotFoundException{
        logger.info("MessageBoard loadMessageBoard: " + filename);

        ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename));
        // load boardName attribute
        boardName = (String) in.readObject();
        // load Post array
        Post[] postArray = (Post[]) in.readObject();
        // convert Post[] to ArrayList<Post>
        posts = new ArrayList<>(Arrays.asList(postArray));
        in.close();
    }

    public void savePostAsTextFile(int postID, String filename)  throws IDInvalidException, IOException{
        // this should make use of getPostIndex to access the post
        // and save it to a text file using the Post class's saveAsTextFile method
        int index = getPostIndex(postID);
        Post p = posts.get(index);
        p.saveAsTextFile(filename);
        logger.info("MessageBoard savePostAsTextFile file:" + filename);
        logger.info("MessageBoard savePostAsTextFile post:" + p.toString());
    }

}