import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.*;

public class Post implements Serializable {
    private static Logger logger = Logger.getLogger(Post.class.getName());

    // Attributes
    private static int idCounter = 0;
    private int postID;
    private String author;
    private String subject;
    private String message;
    private int date;

    public Post(String author, String subject, String message) {
        this(author, subject, message, null);
    }

    public Post(String author, String subject, String message, LocalDate date) {
        this.postID = ++idCounter;
        this.author = author;
        this.subject = subject;
        this.message = message;
        if (date == null) {
            this.date = (int)LocalDate.now().toEpochDay();
        } else {
            this.date = (int)date.toEpochDay();
        }
        logger.info("Post created: " + this.toString());
    }

    public String toString() {
        String result = "Post[]";//String.format("Post[postID=%d, author=\"%s\", subject=\"%s\", message=\"%s\", date=%s]", //PWL remove date 
                        //        0, author, subject, message.replace("\n", "\\n"), "dd_mm_yy");
        return result;
    }

    void setAuthor(String author) {
        this.author = author;
    }

    void setSubject(String subject) {
        this.subject = subject;
    }

    void setMessage(String message) {
        this.message = message;
    }

    void setDate(LocalDate date) {
        this.date = (int)date.toEpochDay();
    }

    String getAuthor() {
        return author;
    }

    String getSubject() {
        return subject;
    }

    String getMessage() {
        return message;
    }

    int getDate() {
        return date;
    }

    int getPostID() {
        return postID;
    }

    public String toFormattedString() {
        LocalDate postDate = LocalDate.ofEpochDay(this.date);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy");
        String result = "\n------------------  Post " + postID + "  -------------------" + 
        "\nAuthor: " + author + 
        "\nDate: " + postDate.format(formatter) + 
        "\nSubject: " + subject + "\n" + 
        "----  Message:  -------------------------------\n" +  
        message + 
        "\n-----------------------------------------------\n";
        return result;
    }

    public void saveAsTextFile(String filename) throws IOException {
        logger.info("Post saved: " + this.toString());
        BufferedWriter out = new BufferedWriter(new FileWriter(filename));
        out.write( toFormattedString() );
        out.close();
    }

}