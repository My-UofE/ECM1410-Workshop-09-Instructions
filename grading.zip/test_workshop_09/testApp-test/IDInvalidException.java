public class IDInvalidException extends RuntimeException {
    public IDInvalidException(String m) {
        super(m);
    }
}