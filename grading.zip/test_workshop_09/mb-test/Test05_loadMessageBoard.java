import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Test05_loadMessageBoard {
    // Create a test post and display it 
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        MessageBoard mb = new MessageBoard("BOARD_ONE");

        String n1 = "NAME1";
        String s1 = "SUBJECT1";
        String m1 = "CONTENT1";


        int postID1 = mb.addPost(n1,s1,m1);
        System.out.println(mb.getFormattedPost(postID1));
        
        mb.saveMessageBoard("test05.ser");
        System.out.println("Message board saved to test05.ser");
        MessageBoard mb2 = new MessageBoard("BOARD_TWO");
        System.out.println("BOARD NAME:" + mb2.getBoardName());
        mb2.loadMessageBoard("test05.ser");
        System.out.println("BOARD NAME:" + mb2.getBoardName());

        int[] postIDs;
        postIDs = mb2.getPostIDs();
        System.out.println(postIDs.length + " posts found in loaded board");
        for (int i = 0; i < postIDs.length; i++) {
            System.out.println(mb2.getFormattedPost(postIDs[i]));
        }    
    }
}