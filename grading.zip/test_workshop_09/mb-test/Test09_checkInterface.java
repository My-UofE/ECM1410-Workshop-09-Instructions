import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

public class Test09_checkInterface {
    // Create a test post and display it 
    public static void main(String[] args) {
        MessageBoard mb = new MessageBoard("BOARD_ONE");
        List<Class<?>> interfaces = Arrays.asList(mb.getClass().getInterfaces());
        System.out.println(interfaces.size());
        System.out.println(interfaces.contains(MessageBoardInterface.class)); 
    }
}