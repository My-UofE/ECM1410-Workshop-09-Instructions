import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Test03_searchBySubject {
    // Create a test post and display it 
    public static void main(String[] args) {
        MessageBoard mb = new MessageBoard("BOARDTITLE");

        String n1 = "NAME1";
        String s1 = "DOG";
        String m1 = "CONTENT1";

        String n2 = "NAME2";
        String s2 = "dog";
        String m2 = "CONTENT2";

        String n3 = "NAME3";
        String s3 = "CAT";
        String m3 = "CONTENT3";

        int postID1 = mb.addPost(n1,s1,m1);
        int postID2 = mb.addPost(n2,s2,m2);
        int postID3 = mb.addPost(n3,s3,m3);
        
        int[] postIDs = mb.searchPostsBySubject("DOG");
        System.out.println(postIDs.length + " posts found with subject 'DOG'");
        for (int i = 0; i < postIDs.length; i++) {
            System.out.println(mb.getFormattedPost(postIDs[i]));
        }
    }
}