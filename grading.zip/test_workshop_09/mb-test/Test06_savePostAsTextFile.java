import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Test06_savePostAsTextFile {
    // Create a test post and display it 
    public static void main(String[] args) throws IDInvalidException, IOException {
        MessageBoard mb = new MessageBoard("BOARDTITLE");

        String n1 = "NAME1";
        String s1 = "SUBJECT1";
        String m1 = "CONTENT1";


        int postID1 = mb.addPost(n1,s1,m1);
        System.out.println(mb.getFormattedPost(postID1));
        
        mb.savePostAsTextFile(postID1, "test06.txt");
        System.out.println("Post saved to test06.txt");
    }
}