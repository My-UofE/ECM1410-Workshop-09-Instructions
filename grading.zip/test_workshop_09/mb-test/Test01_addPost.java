import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Test01_addPost {
    // Create a test post and display it 
    public static void main(String[] args) {
        MessageBoard mb = new MessageBoard("BOARDTITLE");

        String n1 = "NAME1";
        String s1 = "SUBJECT1";
        String m1 = "CONTENT1";


        int postID1 = mb.addPost(n1,s1,m1);
        String formattedPost = mb.getFormattedPost(postID1);
        //String nowString = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yy"));
        System.out.println(formattedPost);//.replace(nowString,"DD_MM_YY"));
        
    }
}
