import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Test04_searchByDate {
    // Create a test post and display it 
    public static void main(String[] args) {
        MessageBoard mb = new MessageBoard("BOARDTITLE");

        String n1 = "NAME1";
        String s1 = "DOG";
        String m1 = "CONTENT1";
        int d1 = (int)LocalDate.of(2014, 8, 1).toEpochDay();

        String n2 = "NAME2";
        String s2 = "dog";
        String m2 = "CONTENT2";
        int d2 = (int)LocalDate.of(2014, 9, 2).toEpochDay();

        String n3 = "NAME3";
        String s3 = "CAT";
        String m3 = "CONTENT3";
        int d3 = (int)LocalDate.of(2014, 9,3).toEpochDay();



        int postID1 = mb.addPost(n1,s1,m1,d1);
        int postID2 = mb.addPost(n2,s2,m2,d2);
        int postID3 = mb.addPost(n3,s3,m3,d3);

        
        int[] postIDs;
        postIDs = mb.searchPostsByDate(d1-1,d3+1);
        System.out.println(postIDs.length + " posts found between " + (d1-1) + " and " + (d3+1));
        postIDs = mb.searchPostsByDate(d1,d2);
        System.out.println(postIDs.length + " posts found between " + d1 + " and " + d2);


    }
}