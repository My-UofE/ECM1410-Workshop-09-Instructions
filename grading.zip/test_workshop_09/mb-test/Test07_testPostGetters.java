import java.io.IOException;
import java.time.LocalDate;

public class Test07_testPostGetters {
    public static void main(String[] args) {
    String author = "AUTHOR";
    String subject = "SUBJECT";
    String message = "MESSAGE";
        
    Post post = new Post( author,  subject,  message);    
    System.out.println("Author: " + post.getAuthor());
    System.out.println("Subject: " + post.getSubject());
    System.out.println("Message: " + post.getMessage());    

    }
}