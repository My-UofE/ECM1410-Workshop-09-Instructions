#!/bin/bash
{
W9_DIR=./submission

if [[  -f "${W9_DIR}/build/mboard_v1.0.jar" \
    && -f "${W9_DIR}/src/messageboard/Post.java" \
    && -f "${W9_DIR}/src/messageboard/MessageBoard.java" \
    && -f "${W9_DIR}/src/messageboard/MessageBoardInterface.java" \
    && -f "${W9_DIR}/src/messageboard/IDInvalidException.java" \
   ]]; then
   echo PASS: PROJECT STRUCTURE > ./student_outputs/output_TestStructure.txt
else
   echo FAIL: PROJECT STRUCTURE > ./student_outputs/output_TestStructure.txt
fi

#FILE="${W9_DIR}/build/mboard_v1.0.jar"
#if [ -f $FILE ]; then
#   echo "File $FILE exists."
#else
#   echo "File $FILE does not exist."
#fi

declare -a MB_FILES=("Post.java" "MessageBoard.java" "MessageBoardInterface.java" "IDInvalidException.java")
declare -a MB_TESTAPP_FILES=("TestPostApp.java" "TestMBApp.java" "TestMBLoadApp.java")

find $W9_DIR -type f -name "*\.jar"  -exec cp {} ./jar-test/. \;

for FILE in "${MB_FILES[@]}"
do
   # find $W9_DIR -type f -name "$FILE"  -exec cp {} ./mb-test/. \;
   find $W9_DIR -type f -name "$FILE"  -exec sed -e 's/\(package \)/\/\/\1/g' {} > ./mb-test/${FILE} \;
   [ -s ./mb-test/${FILE} ] || rm ./mb-test/${FILE}
done

for FILE in "${MB_TESTAPP_FILES[@]}"
do
   # find $W9_DIR -type f -name "$FILE"  -exec cp {} ./testApp-test/. \;
   find $W9_DIR -type f -name "$FILE"  -exec sed -e 's/\(import[[:space:]]message\)/\/\/\1/g' {} > ./testApp-test/${FILE} \;
   [ -s ./testApp-test/${FILE} ]  || rm ./testApp-test/${FILE}
done

javac -cp ./jar-test/mboard_v1.0.jar ./jar-test/*.java
if [[ $? -eq 0 ]]; then
   echo "TEST00: COMPILED"
else
   echo "TEST00: FAILED_TO_COMPILE"
fi

java -cp ./jar-test/mboard_v1.0.jar:jar-test Test00_MBUI >& student_outputs/output_Test00.txt

if [[ $? -eq 0 ]]; then
   echo "TEST00: RAN"
else
   echo "TEST00: FAILED_TO_RUN"
fi

java_files="IDInvalidException Post MessageBoardInterface MessageBoard MessageBoardUI"
for java_file in $java_files; do
    # Compile the Java file 
    javac -cp ./mb-test ./mb-test/${java_file}.java
    if [[ $? -eq 0 ]]; then
        echo "${java_file}: COMPILED"
    else
        echo "${java_file}: FAILED_TO_COMPILE"
    fi
done

java_files="Test01_addPost Test02_deletePost Test03_searchBySubject Test04_searchByDate Test05_loadMessageBoard Test06_savePostAsTextFile Test07_testPostGetters Test08_MBUI Test09_checkInterface"
for java_file in $java_files; do
    # Compile the Java file
    javac -cp ./mb-test ./mb-test/${java_file}.java
    if [[ $? -eq 0 ]]; then
        echo "${java_file}: COMPILED"
    else
        echo "${java_file}: FAILED_TO_COMPILE"
    fi
done

for java_file in $java_files; do
    # Run the Java file
    java -cp ./mb-test ${java_file} | sed -e "s#$(date +"%d/%m/%y")#dd_mm_yy#g" >& student_outputs/output_${java_file}.txt
    if [[ $? -eq 0 ]]; then
        echo "${java_file}: RAN"
    else
        echo "${java_file}: FAILED_TO_RUN"
    fi
done
mv test05.ser ./student_outputs/.
sed -e "s#$(date +"%d/%m/%y")#dd_mm_yy#g" test06.txt >&   ./student_outputs/output_test06.txt


java_files="IDInvalidException Post MessageBoardInterface MessageBoard TestPostApp TestMBApp TestMBLoadApp"
for java_file in $java_files; do
    # Compile the Java file
    javac -cp ./testApp-test ./testApp-test/${java_file}.java
    if [[ $? -eq 0 ]]; then
        echo "${java_file}: COMPILED"
    else
        echo "${java_file}: FAILED_TO_COMPILE"
    fi
done

java_files="TestPostApp TestMBApp TestMBLoadApp"
for java_file in $java_files; do
    # Run the Java file
    java -cp ./testApp-test ${java_file} >& student_outputs/output_${java_file}.out 2>student_outputs/output_${java_file}_raw.log
   if [[ $? -eq 0 ]]; then
        echo "${java_file}: RAN"
    else
        echo "${java_file}: FAILED_TO_RUN"
    fi
    cat student_outputs/output_${java_file}_raw.log | grep INFO | sort > student_outputs/output_${java_file}.txt
done
mv codingsupport.ser ./student_outputs/.
cat windowspost.txt | sed -e "s#$(date +"%d/%m/%y")#dd_mm_yy#g" >& student_outputs/output_windowspost.txt

score=0
for reference in ./reference/*.txt; do
    ref=$(basename $reference)
    ref="${ref%.*}"
    student=./student_outputs/${ref}.txt
    n=$(wc -l < $student | tr -d '[:blank:]')
    var="$(diff -B -E -Z -y --suppress-common-lines $student $reference | wc -l)"
    if [[ $var -eq 0 ]]; then
        echo ${ref}: PASS
    ((score++))
    elif [[ $n -eq 0 ]]; then
    echo ${ref}: FAILED TO PRODUCE OUTPUT
    else
        echo ${ref}: FAIL
    echo
        echo ">>> ${ref}: differences - submission code output (green) vs model answer (red)"
        echo
        git diff --no-prefix -U1000 --no-index --ignore-space-at-eol   \
             --ignore-cr-at-eol  --ignore-blank-lines  --color \
                $reference $student | tail -n +6 | sed 's/^/   /'
    # diff -B -E -Z $student <(echo "${!ref}")
    echo 
   fi
done
#result=${PWD##*/}
awk "BEGIN {printf \"%.0f\n\", $score*5}" > ../workshop_09_score.txt
#echo ${score} > ../workshop_09_score.txt
echo SUMMARY user passed ${score} of the 15 provided tests
} 2>&1 | tee ../workshop_09_output.txt
