#!bash
mkdir -p test_workshop_09/submission; for i in ./*; do [[ "$i" != ./test_workshop_09 ]] && cp -r "$i" test_workshop_09/submission/.; done
cd test_workshop_09
bash grade_workshop_09.sh
